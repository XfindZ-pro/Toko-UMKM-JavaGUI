package projeksmt2;

import projeksmt2.ui.DashboardForm;
import projeksmt2.util.DBConnection;
import java.sql.Connection;

public class ProjekSMT2 {

    public static void main(String[] args) {
      new DashboardForm().setVisible(true);
    }
}
    